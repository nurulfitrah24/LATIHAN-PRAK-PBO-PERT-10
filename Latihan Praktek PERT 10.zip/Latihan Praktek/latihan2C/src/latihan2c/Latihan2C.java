/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package latihan2c;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JPanel;

public class Latihan2C extends JFrame{
    JButton nurul = new JButton("nurul");
    JButton fitrah = new JButton("fitrah");
    JButton nur = new JButton("nur");
    JButton audrey = new JButton("audrey");
    JButton natasya = new JButton("natasya");
    JButton maya = new JButton("maya");
    JButton fitri = new JButton("fitri");
    JButton puspita = new JButton("puspita");
    JButton sari = new JButton("sari");
 
 public Latihan2C() {
     super(" Grid Layout Beraksi");
     setSize(260, 260);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel pane = new JPanel();
   GridLayout family = new GridLayout(3, 3, 10, 10);
   pane.setLayout(family);
   pane.add(nurul);pane.add(fitrah);pane.add(nur);
   pane.add(audrey);pane.add(natasya);pane.add(maya);
   pane.add(fitri);pane.add(puspita);pane.add(sari);
   
   add(pane);
   setVisible(true);
     
     
 }
    
    public static void main(String[] args) {
        
        Latihan2C frame = new Latihan2C();
        
    }
    
}
