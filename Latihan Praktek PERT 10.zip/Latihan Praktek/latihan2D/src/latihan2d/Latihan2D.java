/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package latihan2d;

import java.awt.Button;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.*;
public class Latihan2D extends JFrame{

 
    public static void main(String[] args) {
        Latihan2D lat2 = new Latihan2D();  
        
        
    }
    public Latihan2D(){
    GridBagLayout grid = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();
        setLayout(grid);
        setTitle("GridBag Layout Example");
        GridBagLayout layout = new GridBagLayout();
    this.setLayout(layout);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.ipady = 30;
    gbc.gridx = 0;
    gbc.gridy = 0;
    this.add(new Button("Button One"), gbc);
    gbc.ipady = 30;
    gbc.gridx = 1;
    gbc.gridy = 0;
    this.add(new Button("Button two"), gbc);
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.ipady = 30;
    gbc.gridx = 2;
    gbc.gridy = 0;
    this.add(new Button("Button Three"), gbc);
    gbc.ipady = 30;
    gbc.gridx = 0;
    gbc.gridy = 1;
    this.add(new Button("Button Four"), gbc);
    gbc.gridx = 1;
    gbc.gridy = 1;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.gridwidth = 2;
    this.add(new Button("Button five"), gbc);
        setSize(300, 300);
        setPreferredSize(getSize());
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
    
    }
    
}
