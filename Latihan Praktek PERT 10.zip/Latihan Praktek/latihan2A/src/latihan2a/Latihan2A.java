/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package latihan2a;

import java.awt.BorderLayout;
import java.awt.Frame;
import javax.swing.*;

public class Latihan2A extends JFrame{

    
        JButton nButt = new JButton("NORTH");
        JButton sButt = new JButton("SOUTH");
        JButton eButt = new JButton("EAST");
        JButton wButt = new JButton("WEST");
        JButton cButt = new JButton("CENTER");

public Latihan2A(){
    super("Border Layout Beraksi");
    setSize(1000, 780);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLayout(new BorderLayout());
        add(nButt, BorderLayout.NORTH);
        add(sButt, BorderLayout.SOUTH);
        add(eButt, BorderLayout.EAST);
        add(wButt, BorderLayout.WEST);
        add(cButt, BorderLayout.CENTER);
        
}
        
    
    public static void main(String[] args) {
        // TODO code application logic here
        Latihan2A frame = new Latihan2A();
        frame.setVisible(true);
    }
    
}
