/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package latihan2b;


import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Container;
import java.awt.FlowLayout;
public class Latihan2B extends JFrame {

    public Latihan2B(){
        
      FlowLayout flowlayout = new FlowLayout(FlowLayout.CENTER, 5, 10);
      
      //Memperoleh konten pane dari frame
      Container container = getContentPane();
      
      //Mengatur layout manager dari content pane
      container.setLayout(flowlayout);
      
      //Menambahkan lima button ke content pane
      container.add(new JButton("Tombol 1"));
      container.add(new JButton("Tombol 2"));
      container.add(new JButton("Tombol 3"));
      container.add(new JButton("Tombol 4")); 
      container.add(new JButton("Tombol 5"));
             
    }
    public static void main(String[] args) {
        // TODO code application logic here
        Latihan2B jendela = new Latihan2B();
        jendela.setTitle("Flowlayout");
        jendela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jendela.setSize(320, 120);
        jendela.setVisible(true);
       
    }
    
}
